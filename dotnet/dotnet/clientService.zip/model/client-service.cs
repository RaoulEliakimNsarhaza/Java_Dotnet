﻿namespace e_commerce_anisawadni.model
{
    public class client_service
    {
        public int id { get; set; }
        public string nomPrenom { get; set; }
        public string email { get; set; }
        public string phone { get; set; }
        public string password { get; set; }
    }
}
