﻿namespace e_commerce_anisawadni.model
{
    public class test
    {
        public int id { get; set; }
        public string nom { get; set; }
    }
}
