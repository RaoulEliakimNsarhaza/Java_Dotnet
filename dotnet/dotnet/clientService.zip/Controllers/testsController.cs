﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using e_commerce_anisawadni.Data;
using e_commerce_anisawadni.model;

namespace e_commerce_anisawadni.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class testsController : ControllerBase
    {
        private readonly Ce_commerce_testcontext _context;

        public testsController(Ce_commerce_testcontext context)
        {
            _context = context;
        }

        // GET: api/tests
        [HttpGet]
        public async Task<ActionResult<IEnumerable<test>>> Gettest()
        {
            return await _context.test.ToListAsync();
        }

        // GET: api/tests/5
        [HttpGet("{id}")]
        public async Task<ActionResult<test>> Gettest(int id)
        {
            var test = await _context.test.FindAsync(id);

            if (test == null)
            {
                return NotFound();
            }

            return test;
        }

        // PUT: api/tests/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> Puttest(int id, test test)
        {
            if (id != test.id)
            {
                return BadRequest();
            }

            _context.Entry(test).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!testExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/tests
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<test>> Posttest(test test)
        {
            _context.test.Add(test);
            await _context.SaveChangesAsync();

            return CreatedAtAction("Gettest", new { id = test.id }, test);
        }

        // DELETE: api/tests/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> Deletetest(int id)
        {
            var test = await _context.test.FindAsync(id);
            if (test == null)
            {
                return NotFound();
            }

            _context.test.Remove(test);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool testExists(int id)
        {
            return _context.test.Any(e => e.id == id);
        }
    }
}
