﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using e_commerce_anisawadni.Data;
using e_commerce_anisawadni.model;

namespace e_commerce_anisawadni.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class client_serviceController : ControllerBase
    {
        private readonly e_commerce_serviceClientContext _context;

        public client_serviceController(e_commerce_serviceClientContext context)
        {
            _context = context;
        }

        // GET: api/client_service
        [HttpGet]
        public async Task<ActionResult<IEnumerable<client_service>>> Getclient_service()
        {
            return await _context.client_service.ToListAsync();
        }

        // GET: api/client_service/5
        [HttpGet("{id}")]
        public async Task<ActionResult<client_service>> Getclient_service(int id)
        {
            var client_service = await _context.client_service.FindAsync(id);

            if (client_service == null)
            {
                return NotFound();
            }

            return client_service;
        }

        // PUT: api/client_service/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> Putclient_service(int id, client_service client_service)
        {
            if (id != client_service.id)
            {
                return BadRequest();
            }

            _context.Entry(client_service).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!client_serviceExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/client_service
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<client_service>> Postclient_service(client_service client_service)
        {
            _context.client_service.Add(client_service);
            await _context.SaveChangesAsync();

            return CreatedAtAction("Getclient_service", new { id = client_service.id }, client_service);
        }

        // DELETE: api/client_service/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> Deleteclient_service(int id)
        {
            var client_service = await _context.client_service.FindAsync(id);
            if (client_service == null)
            {
                return NotFound();
            }

            _context.client_service.Remove(client_service);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool client_serviceExists(int id)
        {
            return _context.client_service.Any(e => e.id == id);
        }
    }
}
