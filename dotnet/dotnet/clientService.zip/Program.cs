﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using e_commerce_anisawadni.Data;
var builder = WebApplication.CreateBuilder(args);
builder.Services.AddDbContext<Ce_commerce_testcontext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("Ce_commerce_testcontext") ?? throw new InvalidOperationException("Connection string 'Ce_commerce_testcontext' not found.")));
builder.Services.AddDbContext<e_commerce_serviceClientContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("e_commerce_serviceClientContext") ?? throw new InvalidOperationException("Connection string 'e_commerce_serviceClientContext' not found.")));

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
