﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using e_commerce_anisawadni.model;

namespace e_commerce_anisawadni.Data
{
    public class e_commerce_serviceClientContext : DbContext
    {
        public e_commerce_serviceClientContext (DbContextOptions<e_commerce_serviceClientContext> options)
            : base(options)
        {
        }

        public DbSet<e_commerce_anisawadni.model.client_service> client_service { get; set; } = default!;
    }
}
