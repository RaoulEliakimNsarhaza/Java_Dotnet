﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using e_commerce_anisawadni.model;

namespace e_commerce_anisawadni.Data
{
    public class Ce_commerce_testcontext : DbContext
    {
        public Ce_commerce_testcontext (DbContextOptions<Ce_commerce_testcontext> options)
            : base(options)
        {
        }

        public DbSet<e_commerce_anisawadni.model.test> test { get; set; } = default!;
    }
}
