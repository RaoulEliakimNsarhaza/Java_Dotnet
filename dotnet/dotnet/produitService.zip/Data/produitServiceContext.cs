﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using produitService.model;

namespace produitService.Data
{
    public class produitServiceContext : DbContext
    {
        public produitServiceContext (DbContextOptions<produitServiceContext> options)
            : base(options)
        {
        }

        public DbSet<produitService.model.product> product { get; set; } = default!;
    }
}
