﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using produitService.model;

namespace produitService.Data
{
    public class categoryServiceContext : DbContext
    {
        public categoryServiceContext (DbContextOptions<categoryServiceContext> options)
            : base(options)
        {
        }

        public DbSet<produitService.model.category> category { get; set; } = default!;
    }
}
