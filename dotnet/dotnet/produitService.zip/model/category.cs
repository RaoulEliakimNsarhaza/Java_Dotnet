﻿namespace produitService.model
{
    public class category
    {
        public int id{get;set;}
        public string designation { get; set; }
    }
}
