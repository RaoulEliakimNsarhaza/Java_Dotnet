﻿namespace produitService.model
{
    public class product
    {
        public int id { get; set; }
        public string designation { get; set; }
        public float prix { get; set; }
        public int stock { get; set; }
        public int category { get; set; }
    }
}
