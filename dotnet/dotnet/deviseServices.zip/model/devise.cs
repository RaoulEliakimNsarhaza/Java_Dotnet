﻿namespace deviseServices.model
{
    public class devise
    {
        public int id { get; set; }
        public string deviseText { get; set; }
    }
}
