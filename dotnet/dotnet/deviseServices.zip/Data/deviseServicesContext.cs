﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using deviseServices.model;

namespace deviseServices.Data
{
    public class deviseServicesContext : DbContext
    {
        public deviseServicesContext (DbContextOptions<deviseServicesContext> options)
            : base(options)
        {
        }

        public DbSet<deviseServices.model.devise> devise { get; set; } = default!;
    }
}
