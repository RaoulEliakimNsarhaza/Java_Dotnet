﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using deviseServices.Data;
using deviseServices.model;

namespace deviseServices.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class devisesController : ControllerBase
    {
        private readonly deviseServicesContext _context;

        public devisesController(deviseServicesContext context)
        {
            _context = context;
        }

        // GET: api/devises
        [HttpGet]
        public async Task<ActionResult<IEnumerable<devise>>> Getdevise()
        {
            return await _context.devise.ToListAsync();
        }

        // GET: api/devises/5
        [HttpGet("{id}")]
        public async Task<ActionResult<devise>> Getdevise(int id)
        {
            var devise = await _context.devise.FindAsync(id);

            if (devise == null)
            {
                return NotFound();
            }

            return devise;
        }

        // PUT: api/devises/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> Putdevise(int id, devise devise)
        {
            if (id != devise.id)
            {
                return BadRequest();
            }

            _context.Entry(devise).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!deviseExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/devises
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<devise>> Postdevise(devise devise)
        {
            _context.devise.Add(devise);
            await _context.SaveChangesAsync();

            return CreatedAtAction("Getdevise", new { id = devise.id }, devise);
        }

        // DELETE: api/devises/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> Deletedevise(int id)
        {
            var devise = await _context.devise.FindAsync(id);
            if (devise == null)
            {
                return NotFound();
            }

            _context.devise.Remove(devise);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool deviseExists(int id)
        {
            return _context.devise.Any(e => e.id == id);
        }
    }
}
